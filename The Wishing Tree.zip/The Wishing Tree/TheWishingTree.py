from graphics import *
import random
import time

def DrawMenu():
    global win
    global TreeList
    global TreeTextList
    global LeftTriangle
    global RightTriangle
    global TreeChoice
    global PrevChoice
    
    currentTree = TreeList[TreeChoice]
    previousTree = TreeList[PrevChoice]
    currentTreeText = TreeTextList[TreeChoice]
    previousTreeText = TreeTextList[PrevChoice]
    
    try:  
        LeftTriangle.draw(win)
        RightTriangle.draw(win)
    except:
        pass
    
    try:
        previousTree.undraw()
        previousTreeText.undraw()
    
    except:
        pass
    
    currentTree.draw(win)
    currentTreeText.draw(win)
    
def UndrawMenu():
    global LeftTriangle
    global RightTriangle
    global TreeList
    global TreeTextList
    global TreeChoice
    
    LeftTriangle.undraw()
    RightTriangle.undraw()
    TreeList[TreeChoice].undraw()
    TreeTextList[TreeChoice].undraw()

def InsideLeftTriangle(CP):
    global LeftTriangle
    if (CP.getX() >= LeftTriangle.getAnchor().getX() - (LeftTriangle.getWidth() / 2) and CP.getX() <= LeftTriangle.getAnchor().getX() + (LeftTriangle.getWidth() / 2)):
        if (CP.getY() >= LeftTriangle.getAnchor().getY() - (LeftTriangle.getHeight() / 2) and CP.getY() <= LeftTriangle.getAnchor().getY() + (LeftTriangle.getHeight() / 2)):
            return True
    
    return False

def InsideRightTriangle(CP):
    global RightTriangle
    if (CP.getX() >= RightTriangle.getAnchor().getX() - (RightTriangle.getWidth() / 2) and CP.getX() <= RightTriangle.getAnchor().getX() + (RightTriangle.getWidth() / 2)):
        if (CP.getY() >= RightTriangle.getAnchor().getY() - (RightTriangle.getHeight() / 2) and CP.getY() <= RightTriangle.getAnchor().getY() + (RightTriangle.getHeight() / 2)):
            return True
    
    return False

def InsideTree(CP):
    global TreeList
    global TreeChoice
    if (CP.getX() >= TreeList[TreeChoice].getAnchor().getX() - (TreeList[TreeChoice].getWidth() / 2) and CP.getX() <= TreeList[TreeChoice].getAnchor().getX() + (TreeList[TreeChoice].getWidth() / 2)):
        if (CP.getY() >= TreeList[TreeChoice].getAnchor().getY() - (TreeList[TreeChoice].getHeight() / 2) and CP.getY() <= TreeList[TreeChoice].getAnchor().getY() + (TreeList[TreeChoice].getHeight() / 2)):
            return True
    
    return False

def getOption(CP):
    global Rect1
    global Rect2
    global Rect3
    global Rect4
    
    if (CP.getX() >= Rect1.getP1().getX() and CP.getX() <= Rect1.getP2().getX() and CP.getY() >= Rect1.getP1().getY() and CP.getY() <= Rect1.getP2().getY()):
        return 1
    elif (CP.getX() >= Rect2.getP1().getX() and CP.getX() <= Rect2.getP2().getX() and CP.getY() >= Rect2.getP1().getY() and CP.getY() <= Rect2.getP2().getY()):
        return 2
    elif (CP.getX() >= Rect3.getP1().getX() and CP.getX() <= Rect3.getP2().getX() and CP.getY() >= Rect3.getP1().getY() and CP.getY() <= Rect3.getP2().getY()):
        return 3
    elif (CP.getX() >= Rect4.getP1().getX() and CP.getX() <= Rect4.getP2().getX() and CP.getY() >= Rect4.getP1().getY() and CP.getY() <= Rect4.getP2().getY()):
        return 4
    else:
        return 0

def AskQuestion(Question, Ans1, Ans2, Ans3, Ans4, rightOption):
    global win
    global parch
    global Opt1
    global Opt2
    global Opt3
    global Opt4
    global Rect1
    global Rect2
    global Rect3
    global Rect4
    global CheckMark
    global RedX
    global WrongAnswers
    
    myQuestion = Image(parch.getAnchor(), Question)
    myQuestion.draw(win)
    Opt1.setText(Ans1)
    Opt2.setText(Ans2)
    Opt3.setText(Ans3)
    Opt4.setText(Ans4)
            
    OptionNotPicked = True
    while (OptionNotPicked):
        CP = win.getMouse()
        pickedOption = getOption(CP)
        if (pickedOption == 0):
            OptionNotPicked = True
        else:
            OptionNotPicked = False
            if (pickedOption == rightOption):
                CheckMark.draw(win)
                time.sleep(1)
                CheckMark.undraw()
                myQuestion.undraw()
                return True
            else:
                RedX.draw(win)
                time.sleep(1)
                RedX.undraw()
                WrongAnswers += 1
                myQuestion.undraw()
                return False
    

def PlayFirTree():
    global win
    global width
    global height
    global parch
    global Opt1
    global Opt2
    global Opt3
    global Opt4
    global Rect1
    global Rect2
    global Rect3
    global Rect4
    global WrongAnswers
    global Objects
    global FirTree
    
    UndrawMenu()
    Janovetz = Image(Point(width / 2, height / 4), 'JeffJanovetz.png')
    JanovetzText = Image(Point(width / 2, 5 * height / 8), 'JanovetzText.PNG')
    ClickHere = Image(Point(width / 2, 7 * height / 8), 'Click.PNG')
    Janovetz.draw(win)
    JanovetzText.draw(win)
    ClickHere.draw(win)
    win.getMouse()
    JanovetzText.undraw()
    ClickHere.undraw()
    
    Rect1.draw(win)
    Rect2.draw(win)
    Rect3.draw(win)
    Rect4.draw(win)
            
    Opt1.draw(win)
    Opt2.draw(win)
    Opt3.draw(win)
    Opt4.draw(win)
    
    WrongAnswers = 0
    QuestionList = []
    for i in range (10):
        QuestionList.append(i)
        
    for i in range(10):
        myQuestion = QuestionList[random.randint(0, len(QuestionList) - 1)]
        QuestionList.remove(myQuestion)
        if (myQuestion == 0):
            AskQuestion('Biology1.PNG','Polio Vaccine','Rabies Vaccine','Smallpox Vaccine','Influenza Vaccine', 2)
            
        elif (myQuestion == 1):
            AskQuestion('Biology2.PNG', 'Cirrhosis', 'Hepatitis', 'Jaundice', 'Coeliac', 4)
        
        elif (myQuestion == 2):
            AskQuestion('Biology3.PNG', 'Mollusca', 'Nematoda', 'Cnidaria', 'Echinodermata', 1)
        
        elif (myQuestion == 3):
            AskQuestion('Biology4.PNG', 'Prophase', 'Metaphase', 'Anaphase', 'Telophase', 1)
        
        elif (myQuestion == 4):
            AskQuestion('Biology5.PNG', 'Influenza', 'COVID-19', 'HIV', 'Herpes', 3)
        
        elif (myQuestion == 5):
            AskQuestion('Biology6.PNG', '21', 'X-Chromosome', 'Y-Chromosome', '18', 1)
        
        elif (myQuestion == 6):
            AskQuestion('Biology7.PNG', 'G1', 'C', 'G2', 'S', 2)
        
        elif (myQuestion == 7):
            AskQuestion('Biology8.PNG', 'Abietic Acid', 'Aspartic Acid', 'Acetic Acid', 'Ascorbic Acid', 4)
        
        elif (myQuestion == 8):
            AskQuestion('Biology9.PNG', 'Gregor Mendel', 'Katherine Esau', 'Carl Linnaeus', 'August Weismann', 3)
            
        elif (myQuestion == 9):
            AskQuestion('Biology10.PNG', 'Kangaroo', 'Fruit Fly', 'Cockroach', 'Cape Sundew', 2)
            
        if (WrongAnswers == 3):
            break
            
     
    Rect1.undraw()
    Rect2.undraw()
    Rect3.undraw()
    Rect4.undraw()
            
    Opt1.undraw()
    Opt2.undraw()
    Opt3.undraw()
    Opt4.undraw()
    
    ClickHere.draw(win)
    
    if (WrongAnswers == 3):
        Fail = Image(Point(width / 2, 5 * height / 8), 'Fail.PNG');
        Fail.draw(win)
        win.getMouse()
        Fail.undraw()
        
    else:
        Success = Image(Point(width / 2, 5 * height / 8), 'BioSuccess.PNG');
        Success.draw(win)
        win.getMouse()
        Success.undraw()
        FirTree = Image(Point(width / 2, 3 * height / 8), 'TreeTrunk.png')
        try:
            Objects.remove('Microscope')
        except:
            pass
    
    ClickHere.undraw()
    Janovetz.undraw()    
            
def PlaySakuraTree():
    global win
    global width
    global height
    global parch
    global Opt1
    global Opt2
    global Opt3
    global Opt4
    global Rect1
    global Rect2
    global Rect3
    global Rect4
    global WrongAnswers
    global Objects
    global SakuraTree
    
    UndrawMenu()
    Pyotr = Image(Point(width / 2, height / 4), 'Pyotr.png')
    PyotrText = Image(Point(width / 2, 5 * height / 8), 'PyotrText.PNG')
    ClickHere = Image(Point(width / 2, 7 * height / 8), 'Click.PNG')
    Pyotr.draw(win)
    PyotrText.draw(win)
    ClickHere.draw(win)
    win.getMouse()
    PyotrText.undraw()
    ClickHere.undraw()
    
    Rect1.draw(win)
    Rect2.draw(win)
    Rect3.draw(win)
    Rect4.draw(win)
            
    Opt1.draw(win)
    Opt2.draw(win)
    Opt3.draw(win)
    Opt4.draw(win)
    
    WrongAnswers = 0
    QuestionList = []
    for i in range (10):
        QuestionList.append(i)
        
    for i in range(10):
        myQuestion = QuestionList[random.randint(0, len(QuestionList) - 1)]
        QuestionList.remove(myQuestion)
        if (myQuestion == 0):
            AskQuestion('FA1.PNG','Hieronymus Bosch','Jan Van Eyck','Pieter Bruegel the Elder','Rembrandt', 2)
            
        elif (myQuestion == 1):
            AskQuestion('FA2.PNG', 'Carl Maria von Weber', 'Johannes Brahms', 'Joseph Haydn', 'Felix Mendelssohn', 4)
        
        elif (myQuestion == 2):
            AskQuestion('FA3.PNG', 'La Campanella', 'La Mer', 'Clair de Lune', 'Prelude to the Afternoon of a Faun', 1)
        
        elif (myQuestion == 3):
            AskQuestion('FA4.PNG', 'Seppuku', 'Self-Immolation', 'Gunshot', 'Drowning', 1)
        
        elif (myQuestion == 4):
            AskQuestion('FA5.PNG', 'Liberty Leading the People', 'The Third of May, 1808', 'Guernica', 'I and the Village', 3)
        
        elif (myQuestion == 5):
            AskQuestion('FA6.PNG', 'Clocks', 'Human Corpses', 'Guns', 'Toy Cars', 1)
        
        elif (myQuestion == 6):
            AskQuestion('FA7.PNG', 'Le Corbusier', 'Frank Lloyd Wright', 'I. M. Pei', 'Ludwig Mies van der Rohe', 2)
        
        elif (myQuestion == 7):
            AskQuestion('FA8.PNG', 'Aida', 'Esmeralda', 'Madame Butterfly', 'Carmen', 4)
        
        elif (myQuestion == 8):
            AskQuestion('FA9.PNG', 'Symphonie Fantastique', 'Gymnopedie', 'Eroica', 'Suite Bergamasque', 3)
            
        elif (myQuestion == 9):
            AskQuestion('FA10.PNG', 'The Oath of the Horatii', 'Venus of Urbino', 'The Death of Marat', 'The Death of Socrates', 2)
            
        if (WrongAnswers == 3):
            break
            
     
    Rect1.undraw()
    Rect2.undraw()
    Rect3.undraw()
    Rect4.undraw()
            
    Opt1.undraw()
    Opt2.undraw()
    Opt3.undraw()
    Opt4.undraw()
    
    ClickHere.draw(win)
    
    if (WrongAnswers == 3):
        Fail = Image(Point(width / 2, 5 * height / 8), 'Fail.PNG');
        Fail.draw(win)
        win.getMouse()
        Fail.undraw()
        
    else:
        Success = Image(Point(width / 2, 5 * height / 8), 'FASuccess.PNG');
        Success.draw(win)
        win.getMouse()
        Success.undraw()
        SakuraTree = Image(Point(width / 2, 3 * height / 8), 'TreeTrunk.png')
        try:
            Objects.remove('Paintbrush')
        except:
            pass
    
    ClickHere.undraw()
    Pyotr.undraw()            

def PlayCactus():
    global win
    global width
    global height
    global parch
    global Opt1
    global Opt2
    global Opt3
    global Opt4
    global Rect1
    global Rect2
    global Rect3
    global Rect4
    global WrongAnswers
    global Objects
    global Cactus
    
    UndrawMenu()
    Rohit = Image(Point(width / 2, height / 4), 'RohitSwain.png')
    RohitText = Image(Point(width / 2, 5 * height / 8), 'RohitText.PNG')
    ClickHere = Image(Point(width / 2, 7 * height / 8), 'Click.PNG')
    Rohit.draw(win)
    RohitText.draw(win)
    ClickHere.draw(win)
    win.getMouse()
    RohitText.undraw()
    ClickHere.undraw()
    
    Rect1.draw(win)
    Rect2.draw(win)
    Rect3.draw(win)
    Rect4.draw(win)
            
    Opt1.draw(win)
    Opt2.draw(win)
    Opt3.draw(win)
    Opt4.draw(win)
    
    WrongAnswers = 0
    QuestionList = []
    for i in range (10):
        QuestionList.append(i)
        
    for i in range(10):
        myQuestion = QuestionList[random.randint(0, len(QuestionList) - 1)]
        QuestionList.remove(myQuestion)
        if (myQuestion == 0):
            AskQuestion('History1.PNG','George Washington','John Adams','Thomas Jefferson','James Madison', 2)
            
        elif (myQuestion == 1):
            AskQuestion('History2.PNG', 'The Santebal', 'The Jinyiwei', 'The Gestapo', 'The Oprichniki', 4)
        
        elif (myQuestion == 2):
            AskQuestion('History3.PNG', 'Japanese-American Internment', 'Muslim Travel Ban', 'Specie Circular', 'Emancipation Proclamation', 1)
        
        elif (myQuestion == 3):
            AskQuestion('History4.PNG', 'Boss Tweed', 'Martin Van Buren', 'Al Capone', 'James Farley', 1)
        
        elif (myQuestion == 4):
            AskQuestion('History5.PNG', 'Han', 'Qin', 'Shang', 'Zhou', 3)
        
        elif (myQuestion == 5):
            AskQuestion('History6.PNG', 'The Diet of Worms', 'The Rivonia Trial', 'Black Friday', 'The Second Defenestration of Prague', 1)
        
        elif (myQuestion == 6):
            AskQuestion('History7.PNG', 'Frederick the Great', 'Catherine the Great', 'Peter the Great', 'Alfred the Great', 2)
        
        elif (myQuestion == 7):
            AskQuestion('History8.PNG', 'Sumer', 'Olmec', 'Indus River Valley Civilization', 'Incan', 4)
        
        elif (myQuestion == 8):
            AskQuestion('History9.PNG', 'Tom Watson', 'Ulysses Grant', 'George McClellan', 'William Jennings Bryan', 3)
            
        elif (myQuestion == 9):
            AskQuestion('History10.PNG', 'Choson Dynasty', 'Meiji Restoration', 'Sengoku Period', 'Ashikaga Shogunate', 2)
            
        if (WrongAnswers == 3):
            break
            
     
    Rect1.undraw()
    Rect2.undraw()
    Rect3.undraw()
    Rect4.undraw()
            
    Opt1.undraw()
    Opt2.undraw()
    Opt3.undraw()
    Opt4.undraw()
    
    ClickHere.draw(win)
    
    if (WrongAnswers == 3):
        Fail = Image(Point(width / 2, 5 * height / 8), 'Fail.PNG');
        Fail.draw(win)
        win.getMouse()
        Fail.undraw()
        
    else:
        Success = Image(Point(width / 2, 5 * height / 8), 'HistorySuccess.PNG');
        Success.draw(win)
        win.getMouse()
        Success.undraw()
        Cactus = Image(Point(width / 2, 3 * height / 8), 'TreeTrunk.png')
        try:
            Objects.remove('Cannon')
        except:
            pass
    
    ClickHere.undraw()
    Rohit.undraw()

def PlayRedwoodTree():
    global win
    global width
    global height
    global parch
    global Opt1
    global Opt2
    global Opt3
    global Opt4
    global Rect1
    global Rect2
    global Rect3
    global Rect4
    global WrongAnswers
    global Objects
    global RedwoodTree
    
    UndrawMenu()
    Godwin = Image(Point(width / 2, height / 4), 'Godwin.png')
    GodwinText = Image(Point(width / 2, 5 * height / 8), 'GodwinText.PNG')
    ClickHere = Image(Point(width / 2, 7 * height / 8), 'Click.PNG')
    Godwin.draw(win)
    GodwinText.draw(win)
    ClickHere.draw(win)
    win.getMouse()
    GodwinText.undraw()
    ClickHere.undraw()
    
    Rect1.draw(win)
    Rect2.draw(win)
    Rect3.draw(win)
    Rect4.draw(win)
            
    Opt1.draw(win)
    Opt2.draw(win)
    Opt3.draw(win)
    Opt4.draw(win)
    
    WrongAnswers = 0
    QuestionList = []
    for i in range (10):
        QuestionList.append(i)
        
    for i in range(10):
        myQuestion = QuestionList[random.randint(0, len(QuestionList) - 1)]
        QuestionList.remove(myQuestion)
        if (myQuestion == 0):
            AskQuestion('Physics1.PNG','Moment of Inertia','Torque','Power','Linear Momentum', 2)
            
        elif (myQuestion == 1):
            AskQuestion('Physics2.PNG', 'Teslas', 'Farads', 'Henries', 'Seconds', 4)
        
        elif (myQuestion == 2):
            AskQuestion('Physics3.PNG', 'Photoelectric Effect', 'Hawking Radiation', 'Heisenberg Uncertainty Principle', 'Doppler Effect', 1)
        
        elif (myQuestion == 3):
            AskQuestion('Physics4.PNG', 'Power', 'Impulse', 'Linear Momentum', 'Torque', 1)
        
        elif (myQuestion == 4):
            AskQuestion('Physics5.PNG', 'Zeroth', 'First', 'Second', 'Third', 3)
        
        elif (myQuestion == 5):
            AskQuestion('Physics6.PNG', 'Magnetic Field', 'Electric Field', 'Capacitance', 'Inductance', 1)
        
        elif (myQuestion == 6):
            AskQuestion('Physics7.PNG', 'Alpha Decay', 'Beta-Minus Decay', 'Beta-Plus Decay', 'Gamma Decay', 2)
        
        elif (myQuestion == 7):
            AskQuestion('Physics8.PNG', '100 Degrees Celsius', 'Critical Point', '0 Degrees Celsius', 'Curie Temperature', 4)
        
        elif (myQuestion == 8):
            AskQuestion('Physics9.PNG', 'Infrared', 'Radio Waves', 'X-Rays', 'Microwaves', 3)
            
        elif (myQuestion == 9):
            AskQuestion('Physics10.PNG', '2π Seconds', '4π Seconds', '2 Seconds', '4 Seconds', 2)
            
        if (WrongAnswers == 3):
            break
            
     
    Rect1.undraw()
    Rect2.undraw()
    Rect3.undraw()
    Rect4.undraw()
            
    Opt1.undraw()
    Opt2.undraw()
    Opt3.undraw()
    Opt4.undraw()
    
    ClickHere.draw(win)
    
    if (WrongAnswers == 3):
        Fail = Image(Point(width / 2, 5 * height / 8), 'Fail.PNG');
        Fail.draw(win)
        win.getMouse()
        Fail.undraw()
        
    else:
        Success = Image(Point(width / 2, 5 * height / 8), 'PhysicsSuccess.PNG');
        Success.draw(win)
        win.getMouse()
        Success.undraw()
        RedwoodTree = Image(Point(width / 2, 3 * height / 8), 'TreeTrunk.png')
        try:
            Objects.remove('Pendulum')
        except:
            pass
    
    ClickHere.undraw()
    Godwin.undraw()

def PlayOakTree():
    global win
    global width
    global height
    global parch
    global Opt1
    global Opt2
    global Opt3
    global Opt4
    global Rect1
    global Rect2
    global Rect3
    global Rect4
    global WrongAnswers
    global Objects
    global OakTree
    
    UndrawMenu()
    Flanny = Image(Point(width / 2, height / 4), 'Flanny.png')
    FlannyText = Image(Point(width / 2, 5 * height / 8), 'FlannyText.PNG')
    ClickHere = Image(Point(width / 2, 7 * height / 8), 'Click.PNG')
    Flanny.draw(win)
    FlannyText.draw(win)
    ClickHere.draw(win)
    win.getMouse()
    FlannyText.undraw()
    ClickHere.undraw()
    
    Rect1.draw(win)
    Rect2.draw(win)
    Rect3.draw(win)
    Rect4.draw(win)
            
    Opt1.draw(win)
    Opt2.draw(win)
    Opt3.draw(win)
    Opt4.draw(win)
    
    WrongAnswers = 0
    QuestionList = []
    for i in range (10):
        QuestionList.append(i)
        
    for i in range(10):
        myQuestion = QuestionList[random.randint(0, len(QuestionList) - 1)]
        QuestionList.remove(myQuestion)
        if (myQuestion == 0):
            AskQuestion('Lit1.PNG','Nick Carraway','Holden Caulfield','Werther','Claude Frollo', 2)
            
        elif (myQuestion == 1):
            AskQuestion('Lit2.PNG', 'Dover Beach', 'Chicago', 'Howl', 'The Waste Land', 4)
        
        elif (myQuestion == 2):
            AskQuestion('Lit3.PNG', 'Giants', 'Dragons', 'Demons', 'Griffins', 1)
        
        elif (myQuestion == 3):
            AskQuestion('Lit4.PNG', "Grover's Corners", 'Lowood', 'Middlemarch', 'Macondo', 1)
        
        elif (myQuestion == 4):
            AskQuestion('Lit5.PNG', 'Five', 'Seven', 'Nine', 'Eleven', 3)
        
        elif (myQuestion == 5):
            AskQuestion('Lit6.PNG', 'Zora Neale Hurston', 'Toni Morrison', 'Maya Angelou', 'Nadine Gordimer', 1)
        
        elif (myQuestion == 6):
            AskQuestion('Lit7.PNG', 'Sailing to Byzantium', 'The Second Coming', 'Ozymandias', 'Charge of the Light Brigade', 2)
        
        elif (myQuestion == 7):
            AskQuestion('Lit8.PNG', 'Kenzaburo Oe', 'Kazuo Ishiguro', 'Yasunari Kawabata', 'Yukio Mishima', 4)
        
        elif (myQuestion == 8):
            AskQuestion('Lit9.PNG', 'The Man Who Laughs', 'The Toilers of the Sea', 'Les Miserables', 'The Hunchback of Notre Dame', 3)
            
        elif (myQuestion == 9):
            AskQuestion('Lit10.PNG', 'Ray Bradbury', 'Kurt Vonnegut', 'Douglas Adams', 'David Foster Wallace', 2)
            
        if (WrongAnswers == 3):
            break
            
     
    Rect1.undraw()
    Rect2.undraw()
    Rect3.undraw()
    Rect4.undraw()
            
    Opt1.undraw()
    Opt2.undraw()
    Opt3.undraw()
    Opt4.undraw()
    
    ClickHere.draw(win)
    
    if (WrongAnswers == 3):
        Fail = Image(Point(width / 2, 5 * height / 8), 'Fail.PNG');
        Fail.draw(win)
        win.getMouse()
        Fail.undraw()
        
    else:
        Success = Image(Point(width / 2, 5 * height / 8), 'LitSuccess.PNG');
        Success.draw(win)
        win.getMouse()
        Success.undraw()
        OakTree = Image(Point(width / 2, 3 * height / 8), 'TreeTrunk.png')
        try:
            Objects.remove('Pencil')
        except:
            pass
    
    ClickHere.undraw()
    Flanny.undraw()

def PlayBinaryTree():
    global win
    global width
    global height
    global parch
    global Opt1
    global Opt2
    global Opt3
    global Opt4
    global Rect1
    global Rect2
    global Rect3
    global Rect4
    global WrongAnswers
    global Objects
    global BinaryTree
    
    UndrawMenu()
    DeG = Image(Point(width / 2, height / 4), 'DeG.PNG')
    DeGText = Image(Point(width / 2, 5 * height / 8), 'DeGText.PNG')
    ClickHere = Image(Point(width / 2, 7 * height / 8), 'Click.PNG')
    DeG.draw(win)
    DeGText.draw(win)
    ClickHere.draw(win)
    win.getMouse()
    DeGText.undraw()
    ClickHere.undraw()
    
    Rect1.draw(win)
    Rect2.draw(win)
    Rect3.draw(win)
    Rect4.draw(win)
            
    Opt1.draw(win)
    Opt2.draw(win)
    Opt3.draw(win)
    Opt4.draw(win)
    
    WrongAnswers = 0
    QuestionList = []
    for i in range (10):
        QuestionList.append(i)
        
    for i in range(10):
        myQuestion = QuestionList[random.randint(0, len(QuestionList) - 1)]
        QuestionList.remove(myQuestion)
        if (myQuestion == 0):
            AskQuestion('Math1.PNG','Stack','Queue','Tree','Array', 2)
            
        elif (myQuestion == 1):
            AskQuestion('Math2.PNG', 'n!', 'n * log(n)', 'n', 'n^2', 4)
        
        elif (myQuestion == 2):
            AskQuestion('Math3.PNG', 'Alan Turing', 'Linus Torvalds', 'Edsger Dijkstra', 'George Boole', 1)
        
        elif (myQuestion == 3):
            AskQuestion('Math4.PNG', "p → q", '~p ^ ~q', 'p', 'q', 1)
        
        elif (myQuestion == 4):
            AskQuestion('Math5.PNG', 'Six', 'Ten', 'Sixteen', 'Sixty', 3)
        
        elif (myQuestion == 5):
            AskQuestion('Math6.PNG', '4', '-4', '20', '-20', 1)
        
        elif (myQuestion == 6):
            AskQuestion('Math7.PNG', 'Binomial Coefficients', 'Prime Numbers', 'Triangle Numbers', 'Perfect Numbers', 2)
        
        elif (myQuestion == 7):
            AskQuestion('Math8.PNG', '-sin(4x)', '4cos(4x)', '4sin(4x)', '-4sin(4x)', 4)
        
        elif (myQuestion == 8):
            AskQuestion('Math9.PNG', 'Correlation Coefficient', 'T-Score', 'Standard Deviation', 'Z-Score', 3)
            
        elif (myQuestion == 9):
            AskQuestion('Math10.PNG', 'Square Root of 2', '(π^2)/6', 'The Golden Ratio', '(e^π) / (π^e)', 2)
            
        if (WrongAnswers == 3):
            break
            
     
    Rect1.undraw()
    Rect2.undraw()
    Rect3.undraw()
    Rect4.undraw()
            
    Opt1.undraw()
    Opt2.undraw()
    Opt3.undraw()
    Opt4.undraw()
    
    ClickHere.draw(win)
    
    if (WrongAnswers == 3):
        Fail = Image(Point(width / 2, 5 * height / 8), 'Fail.PNG');
        Fail.draw(win)
        win.getMouse()
        Fail.undraw()
        
    else:
        Success = Image(Point(width / 2, 5 * height / 8), 'MathSuccess.PNG');
        Success.draw(win)
        win.getMouse()
        Success.undraw()
        BinaryTree = Image(Point(width / 2, 3 * height / 8), 'TreeTrunk.png')
        try:
            Objects.remove('Qubit')
        except:
            pass
    
    ClickHere.undraw()
    DeG.undraw()

def PlayYggdrasil():
    global win
    global width
    global height
    global parch
    global Opt1
    global Opt2
    global Opt3
    global Opt4
    global Rect1
    global Rect2
    global Rect3
    global Rect4
    global WrongAnswers
    global Objects
    global Yggdrasil
    
    UndrawMenu()
    Odin = Image(Point(width / 2, height / 4), 'Odin.png')
    OdinText = Image(Point(width / 2, 5 * height / 8), 'OdinText.PNG')
    ClickHere = Image(Point(width / 2, 7 * height / 8), 'Click.PNG')
    Odin.draw(win)
    OdinText.draw(win)
    ClickHere.draw(win)
    win.getMouse()
    OdinText.undraw()
    ClickHere.undraw()
    
    Rect1.draw(win)
    Rect2.draw(win)
    Rect3.draw(win)
    Rect4.draw(win)
            
    Opt1.draw(win)
    Opt2.draw(win)
    Opt3.draw(win)
    Opt4.draw(win)
    
    WrongAnswers = 0
    QuestionList = []
    for i in range (10):
        QuestionList.append(i)
        
    for i in range(10):
        myQuestion = QuestionList[random.randint(0, len(QuestionList) - 1)]
        QuestionList.remove(myQuestion)
        if (myQuestion == 0):
            AskQuestion('Religion1.PNG','Prometheus','Sisyphus','Midas','Tantalus', 2)
            
        elif (myQuestion == 1):
            AskQuestion('Religion2.PNG', 'Epistle of Jude', 'Gospel of John', 'Book of Acts', 'Book of Revelation', 4)
        
        elif (myQuestion == 2):
            AskQuestion('Religion3.PNG', 'Bhagavad-Gita', 'The Farewell Sermon', 'Bala Kanda', 'Ramayana', 1)
        
        elif (myQuestion == 3):
            AskQuestion('Religion4.PNG', 'Shinto', 'Sikhism', 'Jainism', "Baha'i", 3)
        
        elif (myQuestion == 4):
            AskQuestion('Religion5.PNG', "Ra", 'Anubis', 'Osiris', 'Horus', 1)
        
        elif (myQuestion == 5):
            AskQuestion('Religion6.PNG', 'Ireland', 'Switzerland', 'Estonia', 'Morocco', 1)
        
        elif (myQuestion == 6):
            AskQuestion('Religion7.PNG', 'Ryukyuan', 'Shintoism', 'Christianity', 'Buddhism', 2)
        
        elif (myQuestion == 7):
            AskQuestion('Religion8.PNG', 'Clerical Celibacy', 'Apostolic Succession', 'Infused Righteousness', 'Immaculate Conception', 4)
        
        elif (myQuestion == 8):
            AskQuestion('Religion9.PNG', 'Wicca', 'Rastafarianism', 'Scientology', 'Westboro Baptist', 3)
            
        elif (myQuestion == 9):
            AskQuestion('Religion10.PNG', 'Hernando De Soto', 'Hernan Cortes', 'Francisco Hernandez de Cordoba', 'Juan Diaz de Solis', 2)
            
        if (WrongAnswers == 3):
            break
            
     
    Rect1.undraw()
    Rect2.undraw()
    Rect3.undraw()
    Rect4.undraw()
            
    Opt1.undraw()
    Opt2.undraw()
    Opt3.undraw()
    Opt4.undraw()
    
    ClickHere.draw(win)
    
    if (WrongAnswers == 3):
        Fail = Image(Point(width / 2, 5 * height / 8), 'Fail.PNG');
        Fail.draw(win)
        win.getMouse()
        Fail.undraw()
        
    else:
        Success = Image(Point(width / 2, 5 * height / 8), 'ReligionSuccess.PNG');
        Success.draw(win)
        win.getMouse()
        Success.undraw()
        Yggdrasil = Image(Point(width / 2, 3 * height / 8), 'TreeTrunk.png')
        try:
            Objects.remove('Stone')
        except:
            pass
    
    ClickHere.undraw()
    Odin.undraw()
    
width = 800
height = 1100
gap = 40
win = GraphWin('The Wishing Tree', width, height)
parch = Image(Point(width / 2, height / 2), 'Parchment.png')
parch.draw(win)

TreeChoice = 0
PrevChoice = 1
Objects = ['Microscope', 'Paintbrush', 'Cannon', 'Pendulum', 'Pencil', 'Qubit', 'Stone']
ObjectsLeft = len(Objects)
YggdrasilAvailable = False

FirTree = Image(Point(width / 2, height / 3), 'FirTree.png')
SakuraTree = Image(Point(width / 2, height / 3), 'SakuraTree.png')
Cactus = Image(Point(width / 2, height / 3), 'Cactus.png')
RedwoodTree = Image(Point(width / 2, height / 3), 'RedwoodTree.png')
OakTree = Image(Point(width / 2, height / 3), 'OakTree.png')
BinaryTree = Image(Point(width / 2, height / 3), 'BinaryTree.png')
Yggdrasil = Image(Point(width / 2, height / 3), 'Yggdrasil.png')

FirTreeText = Image(Point(width / 2, 6 * height / 8), 'FirTreeText.png')
SakuraTreeText = Image(Point(width / 2, 6 * height / 8), 'SakuraTreeText.png')
CactusText = Image(Point(width / 2, 6 * height / 8), 'CactusText.png')
RedwoodTreeText = Image(Point(width / 2, 6 * height / 8), 'RedwoodTreeText.png')
OakTreeText = Image(Point(width / 2, 6 * height / 8), 'OakTreeText.png')
BinaryTreeText = Image(Point(width / 2, 6 * height / 8), 'BinaryTreeText.png')
YggdrasilText = Image(Point(width / 2, 6 * height / 8), 'YggdrasilText.png')

TreeList = [FirTree, SakuraTree, Cactus, RedwoodTree, OakTree, BinaryTree, Yggdrasil]
TreeTextList = [FirTreeText, SakuraTreeText, CactusText, RedwoodTreeText, OakTreeText, BinaryTreeText, YggdrasilText]

LeftTriangle = Image(Point(width / 8, 6 * height / 8), 'LeftRedTriangle.png')
RightTriangle = Image(Point(7 * width / 8, 6 * height / 8), 'RightRedTriangle.png')

Rect1 = Rectangle(Point(width / 8, gap + (9 * height / 16)), Point(7 * width / 8, 2 * gap + 9 * height / 16))
Rect2 = Rectangle(Point(width / 8, 3 * gap + (9 * height / 16)), Point(7 * width / 8, 4 * gap + 9 * height / 16))
Rect3 = Rectangle(Point(width / 8, 5 * gap + (9 * height / 16)), Point(7 * width / 8, 6 * gap + 9 * height / 16))
Rect4 = Rectangle(Point(width / 8, 7 * gap + (9 * height / 16)), Point(7 * width / 8, 8 * gap + 9 * height / 16))

Rect1.setFill('white')
Rect2.setFill('white')
Rect3.setFill('white')
Rect4.setFill('white')

Opt1 = Text(Rect1.getCenter(), '')
Opt2 = Text(Rect2.getCenter(), '')
Opt3 = Text(Rect3.getCenter(), '')
Opt4 = Text(Rect4.getCenter(), '')

Opt1.setStyle('bold')
Opt2.setStyle('bold')
Opt3.setStyle('bold')
Opt4.setStyle('bold')

CheckMark = Image(parch.getAnchor(), 'CheckMark.png')
RedX = Image(parch.getAnchor(), 'RedX.png')
WrongAnswers = 0
    
Intro1 = Image(Point(width / 2, 5 * height / 32), 'Intro1.PNG')
Intro2 = Image(Point(width / 2, gap + 13 * height / 32), 'Intro2.PNG')
Intro3 = Image(Point(width / 2, 2 * gap + 21 * height / 32), 'Intro3.PNG')
ClickHere = Image(Point(width / 2, 3 * gap + 13 * height / 16), 'Click.PNG')

Intro1.draw(win)
ClickHere.draw(win)
win.getMouse()
Intro2.draw(win)
win.getMouse()
Intro3.draw(win)
win.getMouse()

Intro1.undraw()
Intro2.undraw()
Intro3.undraw()
ClickHere.undraw()

while (True):
    TreeList = [FirTree, SakuraTree, Cactus, RedwoodTree, OakTree, BinaryTree, Yggdrasil]
    
    DrawMenu()
    CP = win.getMouse()
    if (InsideLeftTriangle(CP)):
        PrevChoice = TreeChoice
        TreeChoice -= 1
        
        if (TreeChoice < 0):
            if (YggdrasilAvailable == False):
                TreeChoice = 5
            else:
                TreeChoice = 6
    
    elif (InsideRightTriangle(CP)):
        PrevChoice = TreeChoice
        TreeChoice += 1
        
        if (TreeChoice == 6):
            if (YggdrasilAvailable == False):
                TreeChoice = 0
         
        elif (TreeChoice > 6):
            TreeChoice = 0
        
    elif (InsideTree(CP)):
        if (TreeChoice == 0):
            PlayFirTree()
                
        elif (TreeChoice == 1):
            PlaySakuraTree()
                
        elif (TreeChoice == 2):
            PlayCactus()
                
        elif (TreeChoice == 3):
            PlayRedwoodTree()
                
        elif (TreeChoice == 4):
            PlayOakTree()
                
        elif (TreeChoice == 5):
            PlayBinaryTree()
                
        elif (TreeChoice == 6):
            PlayYggdrasil()
    
    
    if (len(Objects) == 1 and YggdrasilAvailable == False):
        YggdrasilAvailable = True
        YggAvailable = Image(Point(width / 2, 2 * height / 3), 'YggAvailable.PNG')
        YggAvailable.draw(win)
        ClickHere = Image(Point(width / 2, 7 * height / 8), 'Click.PNG')
        ClickHere.draw(win)
        Yggdrasil = Image(Point(width / 2, height / 4), 'Yggdrasil.png')
        Yggdrasil.draw(win)
        win.getMouse()
        YggAvailable.undraw()
        ClickHere.undraw()
        Yggdrasil.undraw()
        Yggdrasil = Image(Point(width / 2, height / 3), 'Yggdrasil.png')
    
    #UndrawMenu();
     
    