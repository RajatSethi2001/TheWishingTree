Title: The Wishing Tree (Story-Telling Game)
Author: Rajat Sethi
Date Due: 3/13/2020
Date Submitted: 3/17/2020
Course Title: Game Design
Meeting Times: Tue/Thur/Fri at 1:00 PM

Description: Trivia Video Game. There are 7 trees that are protected by a guardian. Answer
the guardian's questions to retrieve the tree's item. Once the first six trees are complete,
the final tree "Yggdrasil" will appear. 

Honor Code: I have not given nor recieved any unauthorized help on this assignment - Signed: Rajat Sethi
Input File: None, but make sure the sprites and graphics.py are in the same folder
Output File: None

Bibliography: Used Google Images and the GSSM Webpage to collect sprites. Questions obtained from QuizDB.org

Resouces: NA
Tutors: NA

Comments: There are plenty of things I want to add to this game, but I simply do not have the time. I may
add more questions to the future, along with having the game tell players the correct answers and how many
questions they currently have wrong. Side Note: I turned this game in a little late because I wanted to finish
all of the trees and work out all the bugs before I turned anything in. What I presented in class was more of
a demo with three trees. This version has all 7 trees.

Reflection: This project was the longest I've ever had to do, about 40-50 Hours of work. There were two major
components to my work, the sprites and the questions. The sprites sometimes took forever to find and often
needed to be edited for them to work. Then they had to be resized and repositioned appropriately. The questions
and text prompts took even longer simply because I had to make so many of them. I had to make prompts in Word, then
put them into the game for every question I had (70 Prompts for Questions + More for Game Instructions). 